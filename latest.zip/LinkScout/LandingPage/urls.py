from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.process_url_input, name="Home"),
     path('process_url/', views.process_url_input, name='process_url_input'),
]
